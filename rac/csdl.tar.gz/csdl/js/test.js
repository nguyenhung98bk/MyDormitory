if (result = prompt('Chào bạn, năm nay bạn bao nhiêu tuổi?')) {
    document.write(result);
} else {
    document.write('Sao không trả lời à bạn?');
}