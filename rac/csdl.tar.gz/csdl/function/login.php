<html>
	<meta http-equiv="refresh" content="0;url=../index.php">
<body>
	<?php $Username= $_POST["Username"];
	      $Password= $_POST["Password"];	?>
	<?php
		$dbconn = pg_connect("host=localhost dbname=ktx user=postgres password=nguyenhung6256") or die('Could not connect: '. pg_last_error());

		$sql = "SELECT * FROM Accounts";
		$result = pg_query($sql) or die('Query failed: '. pg_last_error());
		while ($line = pg_fetch_row($result)){
		if($line[0]==$Username&&$line[1]==$Password){
			if($line[2]=='sinhvien') header ("Location: ../site/student.php");
			if($line[2]=='quanly') header ("Location: ../site/quanly.php");
		}	
		}
		pg_free_result($result);
		pg_close($dbconn);
	?>
<script>
			alert("Tai khoan hoac mat khau khong chinh xac\n\Nhan OK de tro ve man hinh dang nhap.");
</script>	
</body>
</html>